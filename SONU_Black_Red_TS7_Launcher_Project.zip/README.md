# SONU Black Red Launcher
For TS7 Android head units in landscape. Android 6.0+.

Build: upload this project to a GitHub repository, open Actions, run Build SONU Launcher, then download the SONU-Black-Red-Launcher artifact. Extract it to get app-debug.apk.

Install APK on the head unit. Press Home and choose SONU Black Red Launcher; choose Always if offered. To revert, use Android Settings > Apps > Default apps > Home app (menu wording varies).

Media keys send standard Android media events; support depends on the active player. Maps/YouTube shortcuts work only if those apps are installed. Radio package varies by TS7 firmware and may need adjustment. This does not update or flash firmware/MCU.